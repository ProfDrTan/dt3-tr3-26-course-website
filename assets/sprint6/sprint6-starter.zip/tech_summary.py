"""
CP3405 Sprint 6 - Gold Technical Summary Engine  (STARTER FILE)

Your job: fill in every function marked TODO. Do not rename functions or change
what they return - the self-test (test_engine.py) and your dashboard depend on it.

Market: gold futures, December 2026 (Yahoo symbol GCZ26.CMX).
Timeframes: 1 hour, 1 day, 1 week - the same three tabs you will check on
Investing.com's gold technical page.

Put this file, test_engine.py and the starter/ folder in your repo's engine/ folder.
Run the self-test any time:      python engine/test_engine.py
Run the engine on live data:     python engine/tech_summary.py   (writes signals/latest.json)
"""
import json, datetime as dt
import pandas as pd

SYMBOL = "GCZ26.CMX"
TIMEFRAMES = {"1h": ("60m", "60d"), "1d": ("1d", "2y"), "1w": ("1wk", "10y")}
MA_PERIODS = [5, 10, 20, 50, 100, 200]

# ---------------------------------------------------------------- plumbing (done for you)
def load_csv(path):
    """Read a saved price file (columns: Open, High, Low, Close)."""
    return pd.read_csv(path, index_col=0, parse_dates=True)

def download(interval, period):
    """Download bars from Yahoo Finance and keep completed bars only."""
    import yfinance as yf
    df = yf.download(SYMBOL, interval=interval, period=period, progress=False, auto_adjust=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df[["Open", "High", "Low", "Close"]].dropna()
    return df.iloc[:-1]  # the last bar may still be forming, so drop it

# ---------------------------------------------------------------- 1. moving averages
def sma(close, n):
    """TODO. Simple moving average: the mean of the last n closes.
    Hint: close.rolling(n).mean()  Return a pandas Series."""
    raise NotImplementedError("sma")

def ema(close, n):
    """TODO. Exponential moving average, giving recent closes more weight.
    Use close.ewm(span=n, adjust=False).mean(), and leave it empty (NaN)
    until at least n closes exist. Return a pandas Series."""
    raise NotImplementedError("ema")

# ---------------------------------------------------------------- 2. indicators
def rsi(close, n=14):
    """TODO. RSI = 100 - 100 / (1 + RS), where RS = average gain / average loss.
    Gains are positive changes in close, losses are the size of negative changes.
    Average them with Wilder's smoothing: .ewm(alpha=1/n, adjust=False).mean()
    (NOT a plain rolling mean - that is the most common mistake)."""
    raise NotImplementedError("rsi")

def macd(close):
    """TODO. MACD line = EMA(12) - EMA(26); signal line = EMA(9) of the MACD line.
    Use .ewm(span=..., adjust=False) for all three. Return (macd_line, signal_line)."""
    raise NotImplementedError("macd")

def stochastic(df):
    """TODO. %K = (Close - lowest Low of last 9 bars) / (highest High of last 9 - lowest Low of last 9) * 100
    %D = 6-bar simple average of %K. Return (k, d)."""
    raise NotImplementedError("stochastic")

def cci(df, n=14):
    """TODO. Typical price TP = (High + Low + Close) / 3.
    CCI = (TP - SMA14 of TP) / (0.015 * mean absolute deviation of TP over 14 bars)."""
    raise NotImplementedError("cci")

def williams_r(df, n=14):
    """TODO. %R = -100 * (highest High of 14 - Close) / (highest High of 14 - lowest Low of 14)."""
    raise NotImplementedError("williams_r")

def roc(close, n=12):
    """TODO. Rate of change = (Close / Close 12 bars ago - 1) * 100."""
    raise NotImplementedError("roc")

def atr(df, n=14):
    """TODO. True range = the largest of: High - Low, |High - previous Close|, |Low - previous Close|.
    ATR = Wilder's smoothing of the true range: .ewm(alpha=1/n, adjust=False).mean()"""
    raise NotImplementedError("atr")

# ---------------------------------------------------------------- 3. votes
def ma_votes(last_close, ma_values):
    """TODO. ma_values is a dict like {"SMA5": 4219.5, "EMA5": 4218.0, ...} (12 entries).
    Each votes "Buy" if last_close is above it, "Sell" if below, "Neutral" if equal or missing (NaN).
    Return a dict with the same 12 keys."""
    raise NotImplementedError("ma_votes")

def indicator_votes(v):
    """TODO. v is a dict of the latest indicator values. Return a dict with these 6 keys:
      "RSI(14)":         Buy above 50, Sell below 50; Neutral above 70 or below 30
      "STOCH(9,6)":      Buy if %K > %D and %K < 80; Sell if %K < %D and %K > 20; else Neutral
      "MACD(12,26,9)":   Buy if MACD line > signal line; Sell if below; Neutral if equal
      "CCI(14)":         Buy above 0, Sell below 0; Neutral above +200 or below -200
      "Williams %R(14)": Buy above -50, Sell below -50; Neutral above -20 or below -80
      "ROC(12)":         Buy above 0, Sell below 0; Neutral if exactly 0"""
    raise NotImplementedError("indicator_votes")

# ---------------------------------------------------------------- 4. score, rating, prediction, pivots
def score_and_rating(votes):
    """TODO. S = (number of Buy - number of Sell) / 18.
    Rating: S >= 0.5 Strong Buy; 0.1 <= S < 0.5 Buy; -0.1 < S < 0.1 Neutral;
            -0.5 < S <= -0.1 Sell; S <= -0.5 Strong Sell.  Return (S, rating)."""
    raise NotImplementedError("score_and_rating")

def predict(last_close, s, last_atr):
    """TODO. Predicted next close P = C + 0.1 * S * ATR."""
    raise NotImplementedError("predict")

def pivots(high, low, close):
    """TODO. Classic pivots from the last completed bar: P = (H + L + C) / 3,
    R1 = 2P - L, S1 = 2P - H. Return {"P": .., "R1": .., "S1": ..} rounded to 2 decimals."""
    raise NotImplementedError("pivots")

# ---------------------------------------------------------------- glue (done for you)
def analyse(df):
    c = df["Close"]; last = float(c.iloc[-1])
    mas = {}
    for n in MA_PERIODS:
        mas[f"SMA{n}"] = float(sma(c, n).iloc[-1]); mas[f"EMA{n}"] = float(ema(c, n).iloc[-1])
    m, sig = macd(c); k, d = stochastic(df)
    ind = {"rsi": float(rsi(c).iloc[-1]), "macd": float(m.iloc[-1]), "macd_sig": float(sig.iloc[-1]),
           "stoch_k": float(k.iloc[-1]), "stoch_d": float(d.iloc[-1]), "cci": float(cci(df).iloc[-1]),
           "willr": float(williams_r(df).iloc[-1]), "roc": float(roc(c).iloc[-1]), "atr": float(atr(df).iloc[-1])}
    votes = {**ma_votes(last, mas), **indicator_votes(ind)}
    s, rating = score_and_rating(votes)
    return {"bar_time_utc": str(df.index[-1]), "close": round(last, 2),
            "moving_averages": {k: round(v, 2) for k, v in mas.items()},
            "indicators": {k: round(v, 3) for k, v in ind.items()},
            "votes": votes, "buy": list(votes.values()).count("Buy"), "sell": list(votes.values()).count("Sell"),
            "score": round(s, 4), "rating": rating,
            "predicted_next_close": round(predict(last, s, ind["atr"]), 2),
            "pivots": pivots(float(df["High"].iloc[-1]), float(df["Low"].iloc[-1]), last)}

def main():
    out = {"symbol": SYMBOL, "generated_utc": dt.datetime.utcnow().isoformat(timespec="seconds") + "Z", "timeframes": {}}
    for tf, (iv, per) in TIMEFRAMES.items():
        out["timeframes"][tf] = analyse(download(iv, per))
    import os
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "signals")
    os.makedirs(folder, exist_ok=True)
    json.dump(out, open(os.path.join(folder, "latest.json"), "w"), indent=1)
    for tf, r in out["timeframes"].items():
        print(f"{tf}: {r['rating']:<11} {r['buy']} buy / {r['sell']} sell  next close {r['predicted_next_close']}  (bar {r['bar_time_utc']} UTC)")

if __name__ == "__main__":
    main()
