"""
Self-test for the Sprint 6 gold engine. Runs on frozen data (gold up to Fri 9 Oct 2026)
and checks your numbers and votes against the course reference engine.
Run from the top of your repo:   python engine/test_engine.py
"""
import json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import tech_summary as eng

exp = json.load(open(os.path.join(HERE, "starter", "expected_gold.json")))
NAME = {"rsi": "rsi", "macd": "macd", "macd_sig": "macd_sig", "stoch_k": "stoch_k", "stoch_d": "stoch_d",
        "cci": "cci", "willr": "willr", "roc": "roc", "atr": "atr"}
fails = 0
def check(label, ours, ref, tol):
    global fails
    ok = ours is not None and not (isinstance(ours, float) and math.isnan(ours)) and abs(ours - ref) <= tol
    if not ok: fails += 1
    print(f"  {'PASS' if ok else 'FAIL'}  {label:<18} yours {ours!s:<12} expected {ref}")

for tf, e in exp["timeframes"].items():
    print(f"\n=== {tf} (bar {e['time']}) ===")
    try:
        r = eng.analyse(eng.load_csv(os.path.join(HERE, "starter", f"gold_{tf}.csv")))
    except NotImplementedError as x:
        print(f"  NOT DONE: {x}() still needs writing"); fails += 1; continue
    for k, v in r["moving_averages"].items():
        check(k, v, e["values"][k.lower()], max(0.01, abs(e["values"][k.lower()]) * 1e-4))
    for k, v in r["indicators"].items():
        check(k, v, e["values"][NAME[k]], max(0.05, abs(e["values"][NAME[k]]) * 1e-3))
    for name, vote in e["votes"].items():
        if r["votes"].get(name) != vote:
            fails += 1; print(f"  FAIL  vote {name:<16} yours {r['votes'].get(name)}  expected {vote}")
    check("score", r["score"], e["score"], 1e-3)
    if r["rating"] != e["rating"]: fails += 1; print(f"  FAIL  rating yours {r['rating']} expected {e['rating']}")
    check("predicted", r["predicted_next_close"], e["predicted_0.1"], 0.05)
    for k in ("P", "R1", "S1"): check(f"pivot {k}", r["pivots"][k], e["pivots"][k], 0.02)

print(f"\n{'ALL CHECKS PASSED' if fails == 0 else f'{fails} CHECK(S) FAILED'}")
sys.exit(1 if fails else 0)
